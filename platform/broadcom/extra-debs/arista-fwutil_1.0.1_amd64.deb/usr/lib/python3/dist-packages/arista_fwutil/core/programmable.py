
import subprocess

from .helpers import clog, isDryRun
from .image import ProgrammableImage
from .logging import getLogger

log = getLogger(__name__)

class ProgrammableUpdateError(Exception):
   pass

class Programmable(object):

   NAME = None
   PCI_ADDR = None
   I2C_ADDR = None

   VERSION_CLS = None
   IMAGE_CLS = ProgrammableImage

   IMAGE_RESTRICT = None

   EXTENSION = None

   def __init__(self, product, config):
      self.product = product
      self.config = config

   def version(self):
      raise NotImplementedError

   def getImage(self, version, force=False):
      if self.config is None:
         return None
      image = self.IMAGE_CLS(self.config['firmware'])
      image.readVersion()
      if image.applies(version, force=force, restrict=self.IMAGE_RESTRICT):
         return image
      return None

   def devName(self):
      return self.NAME

   def pciAddr(self):
      return self.PCI_ADDR

   def i2cAddr(self):
      return self.I2C_ADDR

   def preUpgrade(self):
      pass

   def postUpgrade(self):
      pass

   def upgrade(self, force=False):
      version = self.version()
      log.info('%s: current version %s', self, version)
      image = self.getImage(version, force=force)
      if image is None:
         log.info('%s: upgrade unnecessary', self)
         return False
      if not image.validate(self):
         log.error('Invalid image %s', image.path)
         raise ProgrammableUpdateError("Invalid image %s" % image.path)
      log.info('%s: upgrading to version %s', self, image.version)
      clog('%s: upgrading to version %s, this may take a few minutes...', self,
           image.version)
      if not isDryRun():
         self.preUpgrade()
      self.program(image)
      if not isDryRun():
         self.postUpgrade()
      log.info('%s: upgraded to version %s', self, image.version)
      clog('%s: upgraded to version %s', self, image.version)
      return True

# pylint: disable=abstract-method

class SpiReprogramProgrammable(Programmable):

   PROGRAMMER = '/usr/bin/spiReprogram'
   EXTRA_ARGS = []

   def program(self, image):
      cmd = [
         self.PROGRAMMER,
         '-address', self.pciAddr(),
         '-operation', 'write',
         '-imageFilePath', image.path,
      ] + self.EXTRA_ARGS
      if isDryRun():
         log.info('running: %s', cmd)
      else:
         subprocess.check_call(cmd)

class JamProgrammable(Programmable):

   PROGRAMMER = '/usr/bin/jam'
   EXTRA_ARGS = []
   FPGA_NAME = None

   def fpgaName(self):
      return self.FPGA_NAME or self.devName()

   def program(self, image):
      cmd = [
         self.PROGRAMMER,
         '-aPROGRAM',
         '-b%s' % self.pciAddr(),
         '-f%s' % self.fpgaName(),
      ] + self.EXTRA_ARGS + [
         image.path,
      ]
      if isDryRun():
         log.info('running: %s', cmd)
      else:
         subprocess.check_call(cmd)

class XilinxFpga(SpiReprogramProgrammable):
   EXTENSION = 'abit'

class MicrosemiCpld(JamProgrammable):
   EXTENSION = 'astp'

class AlteraFpga(JamProgrammable):
   EXTENSION = 'ajam'
