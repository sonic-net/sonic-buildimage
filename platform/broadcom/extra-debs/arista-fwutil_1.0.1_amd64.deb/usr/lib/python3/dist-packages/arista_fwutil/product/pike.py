
import time

from ..core.helpers import isDryRun, kabinigpio
from ..core.product import Product
from ..programmable.scd import AlteraScd

@Product.registerProduct
class Pike(Product):
   SID = [r'PikeIsland.*']

   class PikeScd(AlteraScd):
      NAME = 'pike_scd'
      FPGA_NAME = 'prairieScd'
      PCI_ADDR = '0000:00:18.7'
      EXTRA_ARGS = [
         '-ddo_real_time_isp=1',
         '-ddo_bypass_cfm1=1',
      ]

   def powerCycle(self):
      if not isDryRun():
         kabinigpio(115, 0) # CONFIG_SEL
         kabinigpio(144, 1) # nCONFIG
         # should reboot now
         time.sleep(1)

   def __init__(self, platform):
      super().__init__(platform)
      self.register(
         (self.PikeScd, self.getFixedScd())
      )
