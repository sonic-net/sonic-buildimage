
from ..core.product import Product
from ..programmable.scd import XilinxScd

class DenaliLinecard(Product):
   def __init__(self, platform):
      super().__init__(platform)
      self.scd = self.getFixedScd()
      self.register(
         (self.LinecardScd, self.scd),
      )

@Product.registerProduct
class Clearwater2(DenaliLinecard):
   SID = [r'Clearwater2.*']
   class LinecardScd(XilinxScd):
      NAME = 'clearwater2_scd'
      PCI_ADDR = '0000:07:00.0'
      # TODO: add support for clearwater2 P1 <= 0x04 (P2+ >= 0x10)
      IMAGE_RESTRICT = lambda _, c, v: v.major >= 0x10 and c.major >= 0x10

@Product.registerProduct
class Wolverine(DenaliLinecard):
   SID = [r'Wolverine.*']
   class LinecardScd(XilinxScd):
      NAME = 'wolverine_scd'
      PCI_ADDR = '0000:08:00.0'
