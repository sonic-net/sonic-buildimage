
import shlex

from .logging import getLogger

log = getLogger(__name__)

class ProgrammableImage(object):
   def __init__(self, path, version=None):
      self.path = path
      self.version = version

   def __str__(self):
      return f'{self.__class__.__name__}({self.path})'

   def applies(self, curver, force=False, restrict=None):
      if restrict is not None and not restrict(curver, self.version):
         return False
      if self.version == curver:
         return False
      if force:
         return True
      return self.version > curver

   def getNotes(self):
      notes = {}
      seen = False
      with open(self.path, mode='rb') as f:
         for line in f.readlines():
            if not line.startswith(b'NOTE'):
               if not seen:
                  continue
               break # NOTE: all notes should be at the top of the firmware
            seen = True
            line = line.decode('utf8').replace(';', ' ').replace('\\"', '"')
            _, key, value = shlex.split(line)
            notes[key] = value
      return notes

   def validate(self, device):
      raise NotImplementedError

   def readVersion(self):
      raise NotImplementedError
