
from ..core.helpers import waitForPciDevice
from ..core.product import Product
from ..programmable.cpld import MicrosemiSysCpld
from ..programmable.scd import XilinxScd

@Product.registerProduct
class Lodoga(Product):
   SID = [r'Lodoga(Ssd)?']

   class LodogaSysCpld(MicrosemiSysCpld):
      NAME = 'lodoga_cpld'
      PCI_ADDR = '0000:00:14.0'
      def postUpgrade(self):
         waitForPciDevice(self.product.scd.addr)

   class LodogaScd(XilinxScd):
      NAME = 'lodoga_scd'
      PCI_ADDR = '0000:02:00.0'
      def preUpgrade(self):
         # disable crc check
         self.product.syscpld.driver.write_byte_data(0x31, 0x00)

   def __init__(self, platform):
      super().__init__(platform)
      self.syscpld = platform.syscpld
      self.scd = self.getFixedScd()
      self.register(
         (self.LodogaSysCpld, self.syscpld),
         (self.LodogaScd, self.scd),
      )
