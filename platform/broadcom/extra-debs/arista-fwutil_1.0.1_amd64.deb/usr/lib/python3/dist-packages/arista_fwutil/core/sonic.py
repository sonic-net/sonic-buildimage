
import os

from .helpers import alterJson, parseKwargConfig
from .logging import getLogger
from .product import Product
from .updater import Updater

from .. import product # pylint: disable=unused-import

log = getLogger(__name__)

class OperatingSystem:

   STORAGE_PATH = None
   FIRMWARE_PATH = None
   CACHE_NAME = 'firmware-update'

   def __init__(self):
      self.product = None
      self.updater = Updater(os.path.join(self.STORAGE_PATH, self.CACHE_NAME))

   def noop(self):
      # NOTE: call this method to ensure os is loaded
      pass

   def load(self, platform):
      pass

class Sonic(OperatingSystem):

   STORAGE_PATH = '/host'
   FIRMWARE_PATH = '/usr/lib/firmware/arista'

   FORCE_UPGRADE = os.path.join(STORAGE_PATH, 'forceFpgaUpgrade')
   DEVICE_PATH = '/usr/share/sonic/device'

   def getMachineConfig(self, key, default=None):
      path = os.path.join(self.STORAGE_PATH, 'machine.conf')
      return parseKwargConfig(path).get(key, default)

   def getPlatformPath(self, path=''):
      platform = self.getMachineConfig('aboot_platform')
      return os.path.join(self.DEVICE_PATH, platform, path)

   def _updateComponents(self, components, images):
      for name, info in components.items():
         devimages = images.get(name)
         if not devimages:
            continue
         info.update(devimages[0]) # TODO: handle multiple images (e.g DPE)

   def _platformName(self, platform):
      # NOTE: Filter variants as done in the platform library
      name = platform.getEeprom().get('SKU')
      assert name is not None, "Could not identify platform via SKU"
      suffixes = ['-ES', '-M', '-SSD']
      for suffix in suffixes:
         if name.endswith(suffix):
            return name[:-len(suffix)]
      return name

   def _updateChassis(self, data, platform):
      current = self._platformName(platform)
      chassis = None
      for name, chassis in list(data['chassis'].items()):
         if name != current:
            del data['chassis'][name]
      data['chassis'][current] = chassis
      return chassis

   def updatePlatformComponentsConfig(self, platform):
      images = self.product.scanImages(self.FIRMWARE_PATH)
      log.debug('Scanned images: %s', images)
      path = self.getPlatformPath('platform_components.json')
      log.debug('Updating %s', path)
      with alterJson(path) as data:
         if hasattr(platform, 'slot'):
            data['module'] = {
               'SUPERVISOR0': { 'component': {} },
               'LINE-CARD': { 'component': {} },
            }
         chassis = self._updateChassis(data, platform)
         self._updateComponents(chassis['component'], images)

   def load(self, platform):
      self.product = Product.getProduct(platform)
      if self.product is None:
         # NOTE: product does not support firmware updates
         return False
      self.updatePlatformComponentsConfig(platform)
      return True
