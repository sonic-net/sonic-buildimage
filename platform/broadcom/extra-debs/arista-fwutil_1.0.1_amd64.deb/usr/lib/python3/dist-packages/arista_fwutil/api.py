
from .core.sonic import Sonic

# TODO: avoid copy paste?
FW_AUTO_INSTALLED = 1
FW_AUTO_UPDATED = 2
FW_AUTO_SCHEDULED = 3
FW_AUTO_ERR_BOOT_TYPE = -1
FW_AUTO_ERR_IMAGE = -2
FW_AUTO_ERR_UNKNOWN = -3

class ComponentApi:
   def __init__(self, api, component):
      self.api = api
      self.component = component
      self.name = str(component.programmable.getComponent())
      self.device_ = None

   @property
   def device(self):
      if self.device_ is None and self.name:
         self.device_ = self.api.os.product.getDevice(self.name)
      return self.device_

   def get_firmware_version(self):
      self.api.os.noop()
      return self.component.programmable.getVersion()

   def get_available_firmware_version(self, image_path):
      self.api.os.noop()
      image = self.device.IMAGE_CLS(image_path)
      image.readVersion()
      return str(image.version)

   def get_firmware_update_notification(self, image_path):
      # pylint: disable=unused-argument
      return "Firmware update will only happen during a cold boot"

   def install_firmware(self, image_path):
      # NOTE: we only support defered update during cold boot
      self.api.os.updater.schedule(self.name, image_path)
      return True

   def update_firmware(self, image_path):
      # NOTE: we only support defered update during cold boot
      self.api.os.updater.schedule(self.name, image_path)
      return True

   def auto_update_firmware(self, image_path, boot_type):
      # NOTE: we only support updates during cold reboot for now
      if boot_type != 'cold':
         return FW_AUTO_ERR_BOOT_TYPE

      self.api.os.updater.schedule(self.name, image_path)
      return FW_AUTO_SCHEDULED

class Api:
   def __init__(self):
      self.components = []
      self.apiobj = None
      self.platform = None
      self.os_ = None

   @property
   def os(self):
      if self.os_ is None:
         self.os_ = Sonic()
         self.os_.load(self.platform)
      return self.os_

   def _maybeSetPlatform(self, component):
      apiobj = component.parent
      if hasattr(apiobj, '_sku'):
         # FIXME: currently does not support upgrading module component
         #        this only applies to upgrading card firmwares from supervisor
         #        therefore set apiobj as the Chassis object
         apiobj = apiobj._parent # pylint: disable=protected-access
      platform = apiobj._platform # pylint: disable=protected-access

      if self.platform is None:
         self.apiobj = apiobj
         self.platform = platform
      else:
         # NOTE: the parent platform should be the same for all components
         assert self.platform == platform
         assert self.apiobj == apiobj

      return True

   def get_component(self, component):
      if not self._maybeSetPlatform(component):
         return None
      c = ComponentApi(self, component)
      self.components.append(component)
      return c
