
from ..core.image import ProgrammableImage
from ..core.logging import getLogger
from ..core.programmable import AlteraFpga, XilinxFpga

log = getLogger(__name__)

class ScdVersion(object):
   def __init__(self, major, minor, flavor):
      self.major = major
      self.minor = minor
      self.flavor = flavor

   def __str__(self):
      # return "%02x.%02x:%d" % (self.major, self.minor, self.flavor)
      return "0x%x%02x%02x" % (self.major, self.flavor, self.minor)

   def __eq__(self, other):
      return \
         self.major == other.major and \
         self.minor == other.minor and \
         self.flavor == other.flavor

   def __lt__(self, other):
      if self.flavor != other.flavor:
         return True
      if self.major < other.major:
         return True
      if self.major == other.major and self.minor < other.minor:
         return True
      return False

   @classmethod
   def fromInt(cls, value):
      major = (value >> 16) & 0xffff
      minor = value & 0xff
      flavor = (value >> 8) & 0xff
      return cls(major, minor, flavor)

class ScdImage(ProgrammableImage):
   def validate(self, device):
      notes = self.getNotes()

      major = int(notes['ARISTA_REVISION'], base=16)
      if major != self.version.major:
         log.warning('%s: has an invalid major revision', self)
         return False

      minor = int(notes.get('ARISTA_MINOR_REVISION', '0'), base=16)
      if minor != self.version.minor:
         log.warning('%s: has an invalid minor revision', self)
         return False

      flavor = notes.get('ARISTA_FLAVOR')
      if flavor is not None and int(flavor, base=16) != self.version.flavor:
         log.warning('%s: has an invalid flavor', self)
         return False

      fname = notes.get('FILE')
      if fname is not None and device.NAME not in fname:
         log.warning('%s: has an invalid file name', self)
         return False

      return True

   def readVersion(self):
      notes = self.getNotes()
      major = int(notes['ARISTA_REVISION'], base=16)
      minor = int(notes.get('ARISTA_MINOR_REVISION', '0'), base=16)
      flavor = int(notes.get('ARISTA_FLAVOR', '0'), base=16)
      self.version = ScdVersion(major, minor, flavor)
      return self.version

class ScdMixin:
   VERSION_CLS = ScdVersion
   IMAGE_CLS = ScdImage

   def __init__(self, product, config, scd):
      super().__init__(product, config)
      self.scd = scd

   def __str__(self):
      return str(self.scd)

   def pciAddr(self):
      return str(self.scd.addr)

   def version(self):
      with self.scd.getMmap() as mm:
         return self.VERSION_CLS.fromInt(mm.read32(0x100))

class XilinxScd(ScdMixin, XilinxFpga):
   pass

class AlteraScd(ScdMixin, AlteraFpga):
   pass
