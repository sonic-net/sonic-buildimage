
from ..core.image import ProgrammableImage
from ..core.logging import getLogger
from ..core.programmable import MicrosemiCpld

log = getLogger(__name__)

class CpldVersion(object):
   def __init__(self, major, minor):
      self.major = major
      self.minor = minor

   def __str__(self):
      return '%x.%x' % (self.major, self.minor)

   def __eq__(self, other):
      return self.major == other.major and \
             self.minor == other.minor

   def __lt__(self, other):
      if self.major < other.major:
         return True
      if self.major == other.major and self.minor < other.minor:
         return True
      return False

   @classmethod
   def fromInt(cls, value):
      major = (value >> 8) & 0xff
      minor = value & 0xff
      return cls(major, minor)

class CpldImage(ProgrammableImage):
   def validate(self, device):
      notes = self.getNotes()

      major = int(notes['ARISTA_REVISION'], base=16)
      if major != self.version.major:
         log.warning('%s: has an invalid major revision', self)
         return False

      minor = int(notes.get('ARISTA_MINOR_REVISION', '0'), base=16)
      if minor != self.version.minor:
         log.warning('%s: has an invalid minor revision', self)
         return False

      fname = notes.get('FILE')
      if fname is not None and device.NAME not in fname:
         log.warning('%s: has an invalid file name', self)
         return False

      return True

   def readVersion(self):
      notes = self.getNotes()
      major = int(notes['ARISTA_REVISION'], base=16)
      minor = int(notes.get('ARISTA_MINOR_REVISION', '0'), base=16)
      self.version = CpldVersion(major, minor)
      return self.version

class SysCpldMixin:

   VERSION_CLS = CpldVersion
   IMAGE_CLS = CpldImage

   def __init__(self, product, config, cpld):
      super().__init__(product, config)
      self.cpld = cpld

   def __str__(self):
      return str(self.cpld)

   def version(self):
      minor = self.cpld.driver.read_byte_data(0x00)
      major = self.cpld.driver.read_byte_data(0x01)
      return self.VERSION_CLS(major, minor)

class MicrosemiSysCpld(SysCpldMixin, MicrosemiCpld):
   pass
