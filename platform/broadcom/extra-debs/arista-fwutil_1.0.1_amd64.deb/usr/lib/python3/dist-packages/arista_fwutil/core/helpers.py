
import json
import os
import subprocess
import time

from contextlib import contextmanager

@contextmanager
def alterJson(path):
   with open(path, encoding='utf8') as f:
      data = json.load(f)

   yield data

   with open(path, 'w', encoding='utf8') as f:
      json.dump(data, f, separators=(',', ': '), indent=4)

_dryRun = False
def isDryRun():
   return _dryRun

def setDryRun(value):
   global _dryRun # pylint: disable=global-statement
   _dryRun = value

def waitForPciDevice(addr, timeout=10):
   begin = time.time()
   path = '/sys/bus/pci/devices/%s' % addr
   while not os.path.exists(path):
      if time.time() - begin > timeout:
         raise TimeoutError
      time.sleep(0.1)

def checkEnvironment():
   # FIXME
   subprocess.check_call(['modprobe', 'i2c-dev'])

def clog(msg, *args):
   try:
      with open('/dev/console', 'w', encoding='utf8') as f:
         f.write('arista: %s\n' % (msg % args))
         f.flush()
   except: # pylint: disable-msg=W0702
      pass

def parseKwargConfig(path):
   data = {}
   try:
      with open(path, encoding='utf8') as f:
         for line in f.readlines():
            line = line.strip()
            if not line:
               continue
            k, v = line.split('=', 1)
            data[k] = v
   except IOError:
      pass
   return data

cmdlineDict = {}
def parseCmdline(path='/proc/cmdline'):
   data = {}
   try:
      with open(path, encoding='utf8') as f:
         for entry in f.read().split():
            idx = entry.find('=')
            if idx == -1:
               data[entry] = None
            else:
               data[entry[:idx]] = entry[idx+1:]
   except IOError:
      pass
   return data

def kabinigpio(gpio, value):
   return subprocess.check_call(['kabinigpio', str(gpio), str(value)])
