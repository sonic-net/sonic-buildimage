
import json
import os
import shutil

from .logging import getLogger

log = getLogger(__name__)

class Updater:
   def __init__(self, path):
      self.path = path
      self.config = os.path.join(path, 'manifest.json')
      self.manifest = {}

   def load(self):
      if not os.path.exists(self.config):
         self.manifest = {}
         return self.manifest

      try:
         with open(self.config, encoding='utf8') as f:
            self.manifest = json.load(f)
      except json.JsonDecodeError:
         os.remove(self.config)

      return self.manifest

   def save(self):
      with open(self.config, 'w', encoding='utf8') as f:
         json.dump(self.manifest, f, separators=(',', ': '), indent=4)

   def wipe(self):
      shutil.rmtree(self.path)
      self.manifest = {}

   def update(self, component, **kwargs):
      self.load()
      for k, v in kwargs.items():
         self.manifest[component][k] = v
      self.save()

   def schedule(self, component, path):
      if not os.path.isdir(self.path):
         os.mkdir(self.path)

      self.load()
      # NOTE: We make a temporary copy of the firmware we want to install
      # This should address the few scenarios were the firmware could
      # disapear after a reboot while keeping things consistent.
      copyPath = os.path.join(self.path, os.path.basename(path))
      shutil.copy(path, copyPath)
      # TODO: something fancier
      self.manifest[component] = {
         "firmware": copyPath,
         "status": "pending",
      }
      self.save()

      print('Component %s scheduled for update with %s' % (component, path))
      print('Update will happen during next cold reboot')
