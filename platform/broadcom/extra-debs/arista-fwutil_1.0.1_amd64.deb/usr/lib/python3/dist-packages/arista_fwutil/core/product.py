
import os
import re
import subprocess
import time
from collections import OrderedDict

import arista # pylint: disable=import-error

from .helpers import clog, isDryRun, parseCmdline
from .logging import getLogger

log = getLogger(__name__)

class Product(object):
   SID = []
   PRODUCTS = []

   def __init__(self, platform):
      self.platform = platform
      self.config = None
      self.devices = OrderedDict()

   def getSid(self):
      return parseCmdline().get('sid')

   def register(self, *args):
      self.devices = OrderedDict() # NOTE: order defines update priority
      for (cls, obj) in args:
         self.devices[cls.NAME] = (cls, obj)

   def findComponents(self, component, cls):
      if isinstance(component, cls):
         yield component
      for c in component.components:
         for s in self.findComponents(c, cls):
            yield s

   def getFixedScd(self):
      if hasattr(self.platform, 'scd'):
         return self.platform.scd
      scds = list(self.findComponents(self.platform, arista.components.scd.Scd))
      # TODO: enhance this for products with 2 scds
      assert len(scds) == 1, "Only supports products with 1 SCD for now"
      return scds[0]

   def getDevice(self, name):
      for cls, obj in self.devices.values():
         if str(obj) == name:
            return cls(self, None, obj)
      return None

   def powerCycle(self):
      for pc in self.platform.getInventory().getPowerCycles():
         if not isDryRun():
            pc.powerCycle()

   def reboot(self):
      log.info('Upgrade requires a powercycle, doing it now')
      clog('Rebooting after upgrade')
      if not isDryRun():
         subprocess.check_call(['sync'])
         time.sleep(1)
      self.powerCycle()

   @classmethod
   def getProduct(cls, platform):
      for product in cls.PRODUCTS:
         for sid in platform.SID:
            for psid in product.SID:
               if re.match(psid, sid):
                  return product(platform)
      return None

   @classmethod
   def registerProduct(cls, product):
      assert product.__name__ not in [p.__name__ for p in cls.PRODUCTS]
      cls.PRODUCTS.append(product)
      return product

   def scanImages(self, path):
      # TODO: make it cleaner cleaner
      EXTENSIONS = (
         '.ajam',
         '.astp',
         '.abit',
      )
      paths = []
      for root, _, files in os.walk(path):
         for f in files:
            if f.endswith(EXTENSIONS):
               paths.append(os.path.join(root, f))

      images = {}
      for cls, obj in self.devices.values():
         devimages = []
         for imagePath in paths:
            name = os.path.basename(imagePath)
            if name.startswith(cls.NAME):
               devimages.append({
                  "firmware": imagePath,
                  "version": str(cls.IMAGE_CLS(imagePath).readVersion()),
               })
         images[str(obj)] = devimages

      return images

   def check(self, updater):
      for cls, obj in self.devices.values():
         info = updater.manifest.get(str(obj))
         dev = cls(self, info, obj)
         version = dev.version()
         available = dev.getImage(version, force=True)
         if available is None:
            log.info('%s is up to date version=%s', dev, version)
         else:
            log.info('%s can be upgraded from %s to %s', dev, version,
                     available.version)

   def update(self, updater, reboot=False):
      devices = []
      # Iterate all devices in priority order and add them to the schedule list
      for cls, obj in self.devices.values():
         name = str(obj)
         info = updater.manifest.get(name)
         if info is None or info['status'] != 'pending':
            continue
         devices.append((name, cls(self, info, obj)))

      upgraded = False
      for name, dev in devices:
         try:
            upgraded |= dev.upgrade(force=True)
            updater.update(name, status='done')
         except Exception as e: # pylint: disable=broad-except
         # except FileNotFoundError: # pylint: disable=broad-except
            updater.update(name, status='failed', reason=str(e))
            log.exception('Failed to update %s on %s', dev.devName(),
                          self.platform)

      if upgraded and reboot:
         self.reboot()
