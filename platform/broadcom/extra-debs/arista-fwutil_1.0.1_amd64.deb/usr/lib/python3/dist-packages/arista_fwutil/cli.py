# Copyright (c) 2022 Arista Networks, Inc.  All rights reserved.
# Arista Networks, Inc. Confidential and Proprietary.

import argparse
import sys

import arista.platforms # pylint: disable=import-error

from .core.helpers import setDryRun, checkEnvironment
from .core.logging import getLogger, setupLogging
from .core.product import Product
from .core.sonic import Sonic

from . import product # pylint: disable=unused-import
from . import __version__

log = getLogger(__name__)

def parseArgs(args):
   parser = argparse.ArgumentParser(
      description= "A tool to upgrade FPGA on Arista products")

   parser.add_argument('-d', '--dry-run', action='store_true',
      help="Dry run only. Don't actually do anything")
   parser.add_argument('-v', '--verbose', action='store_true',
      help='Enable verbose output information for debugging')
   parser.add_argument('-V', '--version', action='version', version=__version__,
      help='Show current program version')

   subs = parser.add_subparsers(dest='action', help="Available actions:")

   sub = subs.add_parser('check', help="Find available versions")

   sub = subs.add_parser('supported', help="Show supported products")

   sub = subs.add_parser('update', help="Upgrade to the provided version")
   sub.add_argument('-n', '--no-reboot', action='store_true',
      help="Disable reboot after upgrading")

   return parser.parse_args(args)

def supported():
   import json
   import inspect
   from .core.programmable import Programmable

   data = {}
   for p in Product.PRODUCTS:
      pdata = []
      for cls in p.__dict__.values():
         if inspect.isclass(cls) and issubclass(cls, Programmable):
            pdata.append(cls.NAME)
      for sid in p.SID:
         data[sid] = pdata

   print(json.dumps(data, indent=4, separators=(',', ': ')))

def check(args, sonic):
   # pylint: disable=unused-argument
   sonic.product.check(sonic.updater)

def update(args, sonic):
   checkEnvironment()
   sonic.product.update(sonic.updater, reboot=not args.no_reboot)

def main(args):
   args = parseArgs(args)
   setupLogging(verbosity='.*/DEBUG' if args.verbose else '.*/INFO')
   setDryRun(args.dry_run)

   if args.action == 'supported':
      supported()
      return

   sonic = Sonic()
   sonic.load(arista.core.platform.getPlatform())
   sonic.updater.load()

   if sonic.product is None:
      print('This product does not support firmware updates')
      return

   if args.action == 'check':
      check(args, sonic)
   elif args.action == 'update':
      update(args, sonic)
   else:
      log.error('Unknown action: "%s" check --help for available actions',
                args.action)

if __name__ == '__main__':
   main(sys.argv[1:])
